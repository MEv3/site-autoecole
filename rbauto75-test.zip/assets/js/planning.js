/* ==========================================================================
   RB Auto 75 — Assistant de réservation des heures de conduite
   --------------------------------------------------------------------------
   Quatre étapes : forfait → lieu et moniteur → planning → paiement.
   Tout se passe dans le navigateur : aucun serveur, aucun cookie, aucun
   script tiers. Le brouillon est gardé dans localStorage, et la demande part
   vers le responsable par WhatsApp ou par e-mail, avec le planning complet.
   Si un back-end est branché plus tard (data-endpoint sur #book), la demande
   lui est envoyée en JSON et les deux boutons deviennent un simple secours.
   ========================================================================== */
(function () {
  'use strict';

  var root = document.getElementById('book');
  if (!root) return;

  /* ----------------------------------------------------------- Paramètres */
  var TEL        = '33769541674';
  var MAIL       = 'rbautopermisexpresse@gmail.com';
  var PRIX_HEURE = 40;   // heure de conduite à la carte, en euros TTC
  var AVANCE     = 500;  // avance versée à la signature, déduite du forfait
  var MAX_JOUR   = 4;    // créneaux maximum sur une même journée
  var H_DEB      = 10;   // premier créneau : 10:00 – 11:00
  var H_FIN      = 20;   // dernier créneau : 19:00 – 20:00
  var DELAI      = 2;    // premier jour réservable : aujourd'hui + 2
  var CLE        = 'rb-planning-v1';

  var JOURS = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
  var MOIS  = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet',
               'août', 'septembre', 'octobre', 'novembre', 'décembre'];

  /* -------------------------------------------------------------- Helpers */
  function $(sel, ctx) { return (ctx || root).querySelector(sel); }
  function $$(sel, ctx) { return Array.prototype.slice.call((ctx || root).querySelectorAll(sel)); }

  function pad(n) { return (n < 10 ? '0' : '') + n; }

  function euros(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' '); }

  function iso(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }

  function parseIso(s) {
    var p = s.split('-');
    return new Date(+p[0], +p[1] - 1, +p[2]);
  }

  function dateLongue(s) {
    var d = parseIso(s);
    return JOURS[d.getDay()] + ' ' + d.getDate() + ' ' + MOIS[d.getMonth()] + ' ' + d.getFullYear();
  }

  function dateCourte(s) {
    var d = parseIso(s);
    return JOURS[d.getDay()].slice(0, 3) + '. ' + d.getDate() + ' ' + MOIS[d.getMonth()].slice(0, 4) + '.';
  }

  /* ------------------------------------------------------------ Les packs
     Lus directement dans le HTML : les prix restent visibles pour Google et
     pour un visiteur sans JavaScript, et il n'y a qu'un seul endroit à
     corriger le jour où ils changent.
  -------------------------------------------------------------------------- */
  var PACKS = {};
  $$('.pack').forEach(function (el) {
    PACKS[el.dataset.pack] = {
      id:    el.dataset.pack,
      nom:   el.dataset.nom,
      boite: el.dataset.boite,
      h:     el.dataset.h ? parseInt(el.dataset.h, 10) : 0,
      prix:  el.dataset.prix ? parseInt(el.dataset.prix, 10) : 0,
      carte: el.dataset.carte === 'oui',
      // Les heures à l'unité se règlent le jour même : pas d'avance à la signature.
      avance: el.dataset.carte !== 'oui' && el.dataset.avance !== 'non'
    };
  });

  /* ------------------------------------------------------------- L'état */
  var state = {
    etape: 1, pack: '', qte: 4, lieu: '', lieuAutre: '', moniteur: 'Peu importe',
    slots: [], paiement: '', nom: '', tel: '', email: '', note: ''
  };

  try {
    var sauve = window.localStorage.getItem(CLE);
    if (sauve) {
      var o = JSON.parse(sauve);
      Object.keys(state).forEach(function (k) {
        if (o[k] !== undefined && o[k] !== null) state[k] = o[k];
      });
      state.etape = 1;
    }
  } catch (e) { /* navigation privée, stockage bloqué : on repart à vide */ }

  function garder() {
    try { window.localStorage.setItem(CLE, JSON.stringify(state)); } catch (e) {}
  }

  /* ------------------------------------------------------------- Calculs */
  function pack() { return PACKS[state.pack] || null; }

  function cible() {
    var p = pack();
    if (!p) return 0;
    return p.carte ? Math.max(1, Math.min(40, state.qte)) : p.h;
  }

  function total() {
    var p = pack();
    if (!p) return 0;
    return p.carte ? cible() * PRIX_HEURE : p.prix;
  }

  function acompte() { return Math.min(AVANCE, total()); }

  function reste() { return Math.max(0, cible() - state.slots.length); }

  function parJour(date) {
    return state.slots.filter(function (s) { return s.date === date; }).length;
  }

  function trier() {
    state.slots.sort(function (a, b) {
      return a.date === b.date ? a.h - b.h : (a.date < b.date ? -1 : 1);
    });
  }

  /* ========================================================== Étape 1 */
  function majPacks() {
    $$('.pack').forEach(function (el) {
      var on = el.dataset.pack === state.pack;
      el.classList.toggle('is-on', on);
      el.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    var p = pack();
    $('#qte-bloc').hidden = !(p && p.carte);
    $('#etape1-suite').hidden = !p;
    $('#pack-resume').textContent = p
      ? (p.carte
          ? cible() + ' h à la carte, ' + euros(total()) + ' € TTC'
          : p.nom + ' — ' + euros(p.prix) + ' € TTC')
      : '';
  }

  $$('.pack').forEach(function (el) {
    el.addEventListener('click', function () {
      if (state.pack && state.pack !== el.dataset.pack && state.slots.length) {
        if (!window.confirm('Changer de forfait va vider les créneaux déjà choisis. On continue ?')) return;
        state.slots = [];
      }
      state.pack = el.dataset.pack;
      var p = pack();
      if (p && p.boite !== '—') {
        state.boite = p.boite;
        var sel = $('#boite');
        if (sel) sel.value = p.boite;
      }
      majPacks(); majPlanning(); majRecap(); garder();
    });
  });

  var qte = $('#qte');
  if (qte) {
    qte.addEventListener('input', function () {
      state.qte = parseInt(qte.value, 10) || 1;
      majPacks(); majPlanning(); majRecap(); garder();
    });
  }

  /* ========================================================== Étape 2 */
  function champ(id, cle) {
    var el = $('#' + id);
    if (!el) return;
    if (state[cle]) el.value = state[cle];
    else if (el.value) state[cle] = el.value;   // valeur par défaut du <select>

    // Le nom et le lieu figurent sur chaque carte de l'emploi du temps :
    // on le redessine à chaque frappe, pas seulement le récapitulatif.
    var suite = function () {
      state[cle] = el.value;
      $('#lieu-autre-bloc').hidden = $('#lieu').value !== 'Autre lieu';
      majPlanning(); majRecap(); garder();
    };
    el.addEventListener('input', suite);
    el.addEventListener('change', suite);
  }
  champ('lieu', 'lieu');
  champ('lieu-autre', 'lieuAutre');
  champ('boite', 'boite');
  champ('moniteur', 'moniteur');
  champ('nom', 'nom');
  champ('tel', 'tel');
  champ('email', 'email');
  champ('note', 'note');

  function lieuTexte() {
    if (state.lieu === 'Autre lieu') return state.lieuAutre || 'Lieu à préciser';
    return state.lieu || 'Lieu à préciser';
  }

  /* ========================================================== Étape 3 */
  var input = $('#date');
  var minDate = new Date();
  minDate.setDate(minDate.getDate() + DELAI);
  if (input) {
    input.min = iso(minDate);
    input.addEventListener('change', majCreneaux);
  }

  function majCreneaux() {
    var zone = $('#creneaux');
    if (!zone) return;
    zone.innerHTML = '';

    var val = input.value;
    if (!val) {
      zone.innerHTML = '<p class="slots__vide">Choisissez d’abord une date.</p>';
      return;
    }

    // Ouvert tous les jours, dimanche compris : seule la date minimale
    // reste à vérifier.
    if (val < iso(minDate)) {
      zone.innerHTML = '<p class="slots__vide">Les réservations ouvrent à partir du ' +
        dateLongue(iso(minDate)) + '.</p>';
      return;
    }

    var plein = parJour(val) >= MAX_JOUR;
    var frag = document.createDocumentFragment();

    for (var h = H_DEB; h < H_FIN; h++) {
      (function (heure) {
        var pris = state.slots.some(function (s) { return s.date === val && s.h === heure; });
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'slot' + (pris ? ' is-on' : '');
        b.textContent = pad(heure) + ':00 – ' + pad(heure + 1) + ':00';
        b.disabled = !pris && (plein || reste() === 0);
        b.setAttribute('aria-pressed', pris ? 'true' : 'false');
        b.addEventListener('click', function () {
          if (pris) {
            state.slots = state.slots.filter(function (s) {
              return !(s.date === val && s.h === heure);
            });
          } else {
            state.slots.push({ date: val, h: heure });
            trier();
          }
          majPlanning(); majCreneaux(); majRecap(); garder();
        });
        frag.appendChild(b);
      })(h);
    }

    var note = document.createElement('p');
    note.className = 'slots__note';
    note.textContent = plein
      ? 'Quatre créneaux sur cette journée, c’est le maximum. Retirez-en un pour en changer.'
      : (reste() === 0
          ? 'Toutes vos heures sont programmées.'
          : 'Il reste ' + reste() + ' h à placer. Maximum ' + MAX_JOUR + ' créneaux par jour.');

    zone.appendChild(frag);
    zone.appendChild(note);
  }

  function majPlanning() {
    var p = pack();
    var faites = state.slots.length;
    var but = cible();

    $('#planning-cible').textContent = but ? faites + ' h / ' + but + ' h' : '—';
    var barre = $('#planning-barre');
    if (barre) barre.style.width = but ? Math.min(100, (faites / but) * 100) + '%' : '0%';

    var alerte = $('#planning-alerte');
    if (alerte) {
      if (!p) {
        alerte.hidden = false;
        alerte.textContent = 'Choisissez d’abord un forfait à l’étape 1.';
      } else if (faites < but) {
        alerte.hidden = false;
        alerte.textContent = 'Programmez exactement ' + but + ' h. Il reste ' + (but - faites) + ' h.';
      } else if (faites > but) {
        alerte.hidden = false;
        alerte.textContent = 'Vous avez programmé ' + (faites - but) + ' h de trop.';
      } else {
        alerte.hidden = true;
      }
    }

    $('#reste-chip').textContent = but ? 'Reste ' + reste() + ' h' : '';
    dessinerAgenda($('#choisis'), true);
    dessinerAgenda($('#agenda'), false);
  }

  /* --------------------------------------------- L'emploi du temps
     Même lecture que l'application du moniteur : une colonne par journée,
     une carte par heure, avec le nom, l'horaire, le forfait et le lieu.
  -------------------------------------------------------------------------- */
  function dessinerAgenda(hote, supprimable) {
    if (!hote) return;
    hote.innerHTML = '';

    if (!state.slots.length) {
      hote.innerHTML = '<p class="agenda__vide">Aucun créneau ajouté pour le moment.</p>';
      return;
    }

    var p = pack();
    var nom = state.nom || 'Votre nom';
    var etiquette = p ? (p.carte ? cible() + ' h à la carte' : p.nom) : 'Forfait à choisir';
    var boite = state.boite || (p && p.boite !== '—' ? p.boite : '');
    var titre = (etiquette + (boite ? ' — boîte ' + boite : '')).toUpperCase();

    var jours = [];
    state.slots.forEach(function (s) {
      var j = jours.filter(function (x) { return x.date === s.date; })[0];
      if (!j) { j = { date: s.date, h: [] }; jours.push(j); }
      j.h.push(s.h);
    });

    jours.forEach(function (j) {
      var bloc = document.createElement('div');
      bloc.className = 'agenda__jour';

      var tete = document.createElement('div');
      tete.className = 'agenda__date';
      tete.innerHTML = '<span>' + dateLongue(j.date) + '</span><span>' + j.h.length + ' h</span>';
      bloc.appendChild(tete);

      j.h.sort(function (a, b) { return a - b; }).forEach(function (h) {
        var item = document.createElement('div');
        item.className = 'agenda__item';
        item.innerHTML =
          '<div class="agenda__ligne"><b>' + nom + '</b>' +
          '<span class="agenda__h">' + pad(h) + ':00 à ' + pad(h + 1) + ':00</span></div>' +
          '<div class="agenda__pack">' + titre + '</div>' +
          '<div class="agenda__lieu">' + lieuTexte() + '</div>';

        if (supprimable) {
          var x = document.createElement('button');
          x.type = 'button';
          x.className = 'agenda__x';
          x.setAttribute('aria-label', 'Retirer le créneau du ' + dateLongue(j.date) + ' à ' + pad(h) + ' h');
          x.innerHTML = '&times;';
          x.addEventListener('click', function () {
            state.slots = state.slots.filter(function (s) {
              return !(s.date === j.date && s.h === h);
            });
            majPlanning(); majCreneaux(); majRecap(); garder();
          });
          item.appendChild(x);
        }
        bloc.appendChild(item);
      });

      hote.appendChild(bloc);
    });
  }

  /* ========================================================== Étape 4 */
  $$('.pay').forEach(function (el) {
    el.addEventListener('click', function () {
      state.paiement = el.dataset.pay;
      $$('.pay').forEach(function (x) {
        var on = x === el;
        x.classList.toggle('is-on', on);
        x.setAttribute('aria-pressed', on ? 'true' : 'false');
      });
      majRecap(); garder();
    });
  });

  function majRecap() {
    var p = pack();
    var lignes = [
      ['Forfait', p ? (p.carte ? cible() + ' h à la carte' : p.nom) : '—'],
      ['Boîte de vitesses', state.boite || '—'],
      ['Heures programmées', state.slots.length + ' h sur ' + (cible() || '—')],
      ['Lieu de rendez-vous', lieuTexte()],
      ['Moniteur', state.moniteur || 'Peu importe'],
      ['Paiement', state.paiement || '—'],
      ['Total', p ? euros(total()) + ' € TTC' : '—']
    ];
    if (p && p.avance) {
      lignes.push(['Avance à la signature', euros(acompte()) + ' € (déduits du forfait)']);
    }

    var tb = $('#recap');
    if (tb) {
      tb.innerHTML = lignes.map(function (l) {
        return '<div class="recap__row"><span>' + l[0] + '</span><b>' + l[1] + '</b></div>';
      }).join('');
    }

    var pret = !!p && state.slots.length === cible() && !!state.paiement &&
               !!state.nom && !!state.tel;
    $$('[data-envoi]').forEach(function (b) { b.disabled = !pret; });
    var man = $('#manque');
    if (man) {
      man.hidden = pret;
      man.textContent = !p ? 'Choisissez un forfait à l’étape 1.'
        : state.slots.length !== cible() ? 'Il reste ' + reste() + ' h à programmer à l’étape 3.'
        : !state.nom || !state.tel ? 'Indiquez votre nom et votre téléphone.'
        : 'Choisissez un moyen de paiement.';
    }
  }

  /* ------------------------------------------------ Le message envoyé */
  function message() {
    var p = pack();
    var l = [];
    l.push('Nouvelle demande de réservation — rbauto75.com');
    l.push('');
    l.push('Élève : ' + state.nom);
    l.push('Téléphone : ' + state.tel);
    if (state.email) l.push('E-mail : ' + state.email);
    l.push('');
    l.push('Forfait : ' + (p.carte ? cible() + ' h à la carte' : p.nom));
    l.push('Boîte : ' + (state.boite || '—'));
    l.push('Total : ' + total() + ' € TTC');
    if (p.avance) l.push('Avance à la signature : ' + acompte() + ' €');
    l.push('Paiement : ' + state.paiement);
    l.push('Lieu : ' + lieuTexte());
    l.push('Moniteur : ' + state.moniteur);
    l.push('');
    l.push('Planning souhaité (' + state.slots.length + ' h) :');

    var courant = '';
    state.slots.forEach(function (s) {
      if (s.date !== courant) { courant = s.date; l.push('— ' + dateLongue(s.date)); }
      l.push('   ' + pad(s.h) + ':00 à ' + pad(s.h + 1) + ':00');
    });

    if (state.note) { l.push(''); l.push('Remarque : ' + state.note); }
    l.push('');
    l.push('Demande envoyée depuis le site, à confirmer sous 48 h.');
    return l.join('\n');
  }

  function confirmer(texte) {
    var z = $('#envoi-statut');
    if (!z) return;
    z.hidden = false;
    z.textContent = texte;
  }

  /* ------------------------------------------ Le paiement par carte en ligne
     Le prestataire du client ne génère le lien de paiement qu'une fois le site
     en ligne. On le collera dans data-lien-cb sur #book : tant qu'il est vide,
     l'option n'apparaît pas et le règlement se fait uniquement sur place.
  -------------------------------------------------------------------------- */
  function lienCb() { return (root.dataset.lienCb || '').trim(); }

  function preparerCb() {
    if (!lienCb()) return;
    var opt = $('#pay-lien');
    if (opt) opt.hidden = false;
    var a = $('#cb-lien');
    if (a) a.href = lienCb();
    var surPlace = $('#pay-sur-place');
    var enLigne  = $('#pay-en-ligne');
    if (surPlace && enLigne) { surPlace.hidden = true; enLigne.hidden = false; }
  }

  /* Le lien n'est proposé qu'une fois le planning parti : on ne fait pas payer
     des créneaux que l'auto-école n'a pas encore confirmés. */
  function offrirCb() {
    var bloc = $('#cb-lien-bloc');
    if (!bloc) return;
    bloc.hidden = !(lienCb() && state.paiement && state.paiement.indexOf('en ligne') > -1);
  }

  /* --------------------------------------------- L'envoi au responsable
     Dès que l'élève confirme, la réservation part chez RB Auto 75. Avec un
     point de réception renseigné (data-endpoint sur #book, voir le README),
     l'envoi est automatique : les créneaux sont créés dans l'agenda de
     l'auto-école et le responsable est prévenu, sans que personne n'ait à
     recopier quoi que ce soit. Sans point de réception, on retombe sur
     WhatsApp ou l'e-mail, qui demandent un geste de plus à l'élève.
  -------------------------------------------------------------------------- */
  function endpoint() { return (root.dataset.endpoint || '').trim(); }

  function charge() {
    var p = pack();
    return {
      nom: state.nom, telephone: state.tel, email: state.email,
      forfait: p.carte ? cible() + ' h à la carte' : p.nom,
      boite: state.boite, heures: state.slots.length,
      total: total(), avance: p.avance ? acompte() : 0,
      paiement: state.paiement, lieu: lieuTexte(), moniteur: state.moniteur,
      creneaux: state.slots, remarque: state.note,
      resume: message(), ics: ics()
    };
  }

  function verrouiller(oui) {
    $$('[data-envoi]').forEach(function (b) { b.disabled = oui; });
  }

  function parWhatsApp() {
    window.open('https://wa.me/' + TEL + '?text=' + encodeURIComponent(message()),
                '_blank', 'noopener');
    confirmer('WhatsApp vient de s’ouvrir avec votre planning. Envoyez le message : ' +
              'nous confirmons les créneaux sous 48 heures.');
    offrirCb();
  }

  function parMail() {
    window.location.href = 'mailto:' + MAIL +
      '?subject=' + encodeURIComponent('Réservation ' + state.slots.length + ' h — ' + state.nom) +
      '&body=' + encodeURIComponent(message());
    confirmer('Votre messagerie vient de s’ouvrir avec le planning pré-rempli. ' +
              'Nous confirmons les créneaux sous 48 heures.');
    offrirCb();
  }

  function envoyer() {
    var url = endpoint();
    if (!url || !window.fetch) { parWhatsApp(); return; }

    var b = $('#envoi');
    var libelle = b ? b.textContent : '';
    verrouiller(true);
    if (b) b.textContent = 'Envoi en cours…';
    confirmer('Transmission de votre planning à RB Auto 75…');

    // Un script Google Apps ne répond pas à la requête préalable CORS : on lui
    // envoie du texte brut, ce qui en fait une requête « simple ».
    var google = url.indexOf('script.google.com') > -1;

    window.fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': google ? 'text/plain;charset=utf-8' : 'application/json' },
      body: JSON.stringify(charge())
    }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.text();
    }).then(function () {
      if (b) b.textContent = 'Réservation envoyée';
      confirmer('C’est envoyé. Vos ' + state.slots.length + ' heure' +
                (state.slots.length > 1 ? 's sont arrivées' : ' est arrivée') +
                ' chez RB Auto 75. Le responsable est prévenu et vous confirme ' +
                'le planning sous 48 heures.');
      offrirCb();
      try { window.localStorage.removeItem(CLE); } catch (e) {}
    })['catch'](function () {
      verrouiller(false);
      if (b) b.textContent = libelle;
      confirmer('L’envoi automatique n’a pas abouti. Passez par WhatsApp ou par e-mail ' +
                'juste en dessous : votre planning est déjà prêt, il n’y a qu’à l’envoyer.');
    });
  }

  var btnEnvoi = $('#envoi');
  if (btnEnvoi) btnEnvoi.addEventListener('click', envoyer);

  var btnWa = $('#envoi-wa');
  if (btnWa) btnWa.addEventListener('click', parWhatsApp);

  var btnMail = $('#envoi-mail');
  if (btnMail) btnMail.addEventListener('click', parMail);

  /* ------------------------------------------- Le planning au format agenda
     Transmis avec la réservation : un point de réception qui ne sait pas
     créer d'événement peut toujours relayer ce bloc tel quel.
  -------------------------------------------------------------------------- */
  function ics() {
    var p = pack();
    var nom = p.carte ? cible() + ' h à la carte' : p.nom;
    var out = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//RB Auto 75//Planning//FR',
               'CALSCALE:GREGORIAN', 'METHOD:PUBLISH'];
    var stamp = new Date().toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';

    state.slots.forEach(function (s, i) {
      var pp = s.date.split('-');
      var deb = new Date(+pp[0], +pp[1] - 1, +pp[2], s.h, 0, 0);
      var fin = new Date(+pp[0], +pp[1] - 1, +pp[2], s.h + 1, 0, 0);
      var fmt = function (d) { return d.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z'; };
      out.push('BEGIN:VEVENT');
      out.push('UID:rbauto75-' + s.date + '-' + s.h + '-' + i + '@rbauto75.com');
      out.push('DTSTAMP:' + stamp);
      out.push('DTSTART:' + fmt(deb));
      out.push('DTEND:' + fmt(fin));
      out.push('SUMMARY:Conduite RB Auto 75 — ' + nom);
      out.push('LOCATION:' + lieuTexte());
      out.push('DESCRIPTION:Heure de conduite avec RB Auto 75. Contact : 07 69 54 16 74.');
      out.push('END:VEVENT');
    });

    out.push('END:VCALENDAR');
    return out.join('\r\n');
  }

  var btnRaz = $('#raz');
  if (btnRaz) {
    btnRaz.addEventListener('click', function () {
      if (!window.confirm('Effacer toute la réservation en cours ?')) return;
      state.pack = ''; state.slots = []; state.paiement = '';
      try { window.localStorage.removeItem(CLE); } catch (e) {}
      $$('.pay').forEach(function (x) { x.classList.remove('is-on'); x.setAttribute('aria-pressed', 'false'); });
      majPacks(); majPlanning(); majCreneaux(); majRecap();
      aller(1);
    });
  }

  /* ======================================================= Navigation */
  function aller(n) {
    state.etape = n;
    $$('.book__panel').forEach(function (pan) {
      pan.hidden = parseInt(pan.dataset.etape, 10) !== n;
    });
    $$('.book__step').forEach(function (st) {
      var i = parseInt(st.dataset.etape, 10);
      st.classList.toggle('is-on', i === n);
      st.classList.toggle('is-done', i < n);
      if (i === n) st.setAttribute('aria-current', 'step');
      else st.removeAttribute('aria-current');
    });
    var tete = $('.book__steps');
    if (tete) {
      var y = tete.getBoundingClientRect().top + window.pageYOffset - 90;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  }

  $$('[data-go]').forEach(function (b) {
    b.addEventListener('click', function () {
      var n = parseInt(b.dataset.go, 10);
      if (n === 2 && !pack()) { majPlanning(); return; }
      aller(n);
      if (n === 3) majCreneaux();
    });
  });

  $$('.book__step').forEach(function (st) {
    st.addEventListener('click', function () {
      var n = parseInt(st.dataset.etape, 10);
      if (n > 1 && !pack()) return;
      aller(n);
      if (n === 3) majCreneaux();
    });
  });

  /* ------------------------------------------------------------ Démarrage */
  root.classList.add('is-ready');
  if (state.paiement) {
    $$('.pay').forEach(function (x) {
      var on = x.dataset.pay === state.paiement;
      x.classList.toggle('is-on', on);
      x.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
  }
  preparerCb();
  if (state.lieu === 'Autre lieu') $('#lieu-autre-bloc').hidden = false;
  if (qte) qte.value = state.qte;
  majPacks();
  majPlanning();
  majCreneaux();
  majRecap();
  aller(1);
})();
